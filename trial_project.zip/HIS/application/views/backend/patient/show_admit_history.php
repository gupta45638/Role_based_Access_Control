<?php
$patient_id         = $this->session->userdata('login_user_id');
$admit_history_info = $this->db->get_where('bed_allotment', array('patient_id' => $patient_id))->result_array();
?>
<table class="table table-bordered table-striped datatable" id="table-2">
    <thead>
        <tr>
            <th><?php echo get_phrase('bed_number');?></th>
            <th><?php echo get_phrase('bed_type');?></th>
            <th><?php echo get_phrase('allotment_time');?></th>
            <th><?php echo get_phrase('discharge_time');?></th>
        </tr>
    </thead>

    <tbody>
        <?php foreach ($admit_history_info as $row) { ?>   
            <tr>
                 <td>
                    <?php $bed_number = $this->db->query('select b.id from bad b, bed_allotment ba where ba.bed_id = b.id')->result_array();?>
                    <?php foreach ($bed_number as $b){
                        if($row['bed_id']==$b['id'])
                           echo $b['id'];
                           
                       };
                        ?>
                </td>
                <td>
                   <?php $bed_number = $this->db->query('select b.name,b.id from bad b, bed_allotment ba where ba.bed_id = b.id')->result_array();?>
                    <?php foreach ($bed_number as $b){
                         if($row['bed_id']==$b['id'])
                           echo $b['name'];
                       };
                        ?>
                </td>
                <td><?php echo date("m/d/Y", $row['allotment_timestamp']); ?></td>
                <td><?php echo date("m/d/Y", $row['discharge_timestamp']); ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>

<script type="text/javascript">
    jQuery(window).load(function ()
    {
        var $ = jQuery;

        $("#table-2").dataTable({
            "sPaginationType": "bootstrap",
            "sDom": "<'row'<'col-xs-3 col-left'l><'col-xs-9 col-right'<'export-data'T>f>r>t<'row'<'col-xs-3 col-left'i><'col-xs-9 col-right'p>>"
        });

        $(".dataTables_wrapper select").select2({
            minimumResultsForSearch: -1
        });

        // Highlighted rows
        $("#table-2 tbody input[type=checkbox]").each(function (i, el)
        {
            var $this = $(el),
                    $p = $this.closest('tr');

            $(el).on('change', function ()
            {
                var is_checked = $this.is(':checked');

                $p[is_checked ? 'addClass' : 'removeClass']('highlight');
            });
        });

        // Replace Checboxes
        $(".pagination a").click(function (ev)
        {
            replaceCheckboxes();
        });
    });
</script>