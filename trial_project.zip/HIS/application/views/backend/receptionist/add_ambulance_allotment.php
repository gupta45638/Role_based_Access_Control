<?php
$driver_info = $this->db->query('SELECT * FROM driver WHERE NOT EXISTS (SELECT name FROM ambulance_allotment WHERE driver.id = ambulance_allotment.driver_id and ambulance_allotment.status = 1  );')->result_array();
$ambulance_info = $this->db->query('SELECT * FROM ambulance WHERE NOT EXISTS (SELECT name FROM ambulance_allotment WHERE ambulance.id = ambulance_allotment.ambulance_id and  ambulance_allotment.status = 1 );')->result_array();


?>
<div class="row">
    <div class="col-md-12">

        <div class="panel panel-primary" data-collapsed="0">

            <div class="panel-heading">
                <div class="panel-title">
                    <h3><?php echo get_phrase('add_ambulance_allotment'); ?></h3>
                </div>
            </div>

            <div class="panel-body">

                <form role="form" class="form-horizontal form-groups" action="<?php echo site_url('receptionist/ambulance_allotment/create'); ?>" 
                    method="post" enctype="multipart/form-data">

                    <div class="form-group">
                        <label for="field-ta" class="col-sm-3 control-label"><?php echo get_phrase('driver'); ?></label>

                        <div class="col-sm-7">
                            <select name="driver_id" class="form-control select2" required>
                                <option value=""><?php echo get_phrase('select_driver'); ?></option>
                                <?php 

                                foreach ($driver_info as $row) { 
                                   ?>

                                    <option value="<?php echo $row['id']; ?>"><?php echo $row['name'] ; ?></option>
                                <?php }?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-ta" class="col-sm-3 control-label"><?php echo get_phrase('Ambulance'); ?></label>

                        <div class="col-sm-7">
                            <select name="ambulance_id" class="form-control select2" required>
                                <option value=""><?php echo get_phrase('ambulance_name-_type'); ?></option>
                                <?php foreach ($ambulance_info as $row){ ?>
                                    <option value="<?php echo $row['id']; ?>"><?php echo $row['name']."-".$row['ambulance_type'];?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                            <label for="field-ta" class="col-sm-3 control-label"><?php echo get_phrase('address'); ?></label>

                            <div class="col-sm-7">
                                <textarea rows="5" name="address" class="form-control" id="field-ta"></textarea>
                            </div>
                    </div>

                    <input type="hidden" value="1" name="status" class="form-control" id="field-1" required>
                    <div class="col-sm-3 control-label col-sm-offset-2">
                        <button type="submit" class="btn btn-success">
                            <i class="fa fa-check"></i> <?php echo get_phrase('save');?>
                        </button>
                    </div>

                </form>

            </div>

        </div>

    </div>
</div>
