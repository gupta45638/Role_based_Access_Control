<?php $version = $this->db->get_where('settings', array('type' => 'version'))->row()->description;?>
<!-- Footer -->
<footer class="main">
	&copy; 2018 <strong>Averoft Hospital Management System</strong>
    <strong class="pull-right"> VERSION <?php echo $version;?></strong>
    Developed by
	<a href="https://www.averoft.com"
    	target="_blank">Averoft</a>
</footer>
