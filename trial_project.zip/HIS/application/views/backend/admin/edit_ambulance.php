<?php 
$single_ambulance_info = $this->db->get_where('ambulance', array('id' => $param2))->result_array();
foreach($single_ambulance_info as $row){
?>
<div class="row">
    <div class="col-md-12">

        <div class="panel panel-primary" data-collapsed="0">

            <div class="panel-heading">
                <div class="panel-title">
                    <h3><?php echo get_phrase('add_ambulance'); ?></h3>
                </div>
            </div>

            <div class="panel-body">

                <form role="form" class="form-horizontal form-groups validate"
                    action="<?php echo site_url('admin/ambulance/update/'.$row['id']); ?>" 
                        method="post" enctype="multipart/form-data">

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label"><?php echo get_phrase('name'); ?></label>

                        <div class="col-sm-7">
                            <input type="text" name="name" class="form-control" id="field-1" value="<?php echo $row['name'];?>" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label"><?php echo get_phrase('vehicle_no'); ?></label>

                        <div class="col-sm-7">
                            <input type="text" name="vehicle_no" class="form-control" id="field-1" value="<?php echo $row['vehicle_no'];?>" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label"><?php echo get_phrase('ambulance_type'); ?></label>

                        <div class="col-sm-7">
                            <input type="text" name="ambulance_type" class="form-control" id="field-1" value="<?php echo $row['ambulance_type'];?>" required>
                        </div>
                    </div>

                    
                    

                    <div class="col-sm-3 control-label col-sm-offset-2">
                        <button type="submit" class="btn btn-success">
                            <i class="fa fa-check"></i> <?php echo get_phrase('save');?>
                        </button>
                    </div>
                </form>

            </div>

        </div>

    </div>
</div>
<?php } ?>