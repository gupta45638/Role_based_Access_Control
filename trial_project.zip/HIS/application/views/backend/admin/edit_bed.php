<?php $wardtype_info = $this->db->get('ward_type')->result_array(); ?>
<?php 
$single_bed_info = $this->db->get_where('bad', array('id' => $param2))->result_array();
foreach($single_bed_info as $row){
?>
<div class="row">
    <div class="col-md-12">

        <div class="panel panel-primary" data-collapsed="0">

            <div class="panel-heading">
                <div class="panel-title">
                    <h3 id="test"><?php echo get_phrase('add_Bed'); ?></h3>
                </div>
            </div>

            <div class="panel-body">

                <form role="form" class="form-horizontal form-groups validate"
                    action="<?php echo site_url('admin/bed/update/'.$row['id']);  ?>" 
                        method="post" enctype="multipart/form-data">

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label"><?php echo get_phrase('name'); ?></label>

                        <div class="col-sm-7">
                            <input type="text" name="name" class="form-control" id="field-1" value="<?php echo $row['name'];?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="field-ta" class="col-sm-3 control-label"><?php echo get_phrase('Wardtype'); ?></label>

                        <div class="col-sm-7">
                            <select name="wardtype_id" class="form-control" id="wardtype_id" required
                                class="form-control">
                                <option value=""><?php echo get_phrase('select_wardtype'); ?></option>
                                <?php foreach ($wardtype_info as $ro) { ?>
                                    <option value="<?php echo $ro['id']; ?>"<?php if ($row['wardtype'] == $ro['id']) echo 'selected'; ?>><?php echo $ro['name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                     <div class="form-group" id = 'warddiv' style="display:none;">
                        <label for="field-3" class="col-sm-3 control-label"><?php echo get_phrase('Ward'); ?></label>

                        <div class="col-sm-7">
                            <select  name="ward_id" class="form-control" id="ward" required
                                class="form-control">
                                
                                <option value="<?php echo $row['ward']?>" ><?php get_phrase('Select Ward');?></option>
                                
                            </select>
                        </div>
                    </div>
                    <div class="form-group" id="bedtypediv" style="display:none;">
                        <label for="field-4" class="col-sm-3 control-label"><?php echo get_phrase('bed type'); ?></label>

                        <div class="col-sm-7">
                            <select  name="bedtype_id" class="form-control" id="bedtype"  required
                                class="form-control">
                                <option value="<?php echo $row['bedtype']?>"><?php echo get_phrase('select_bedtype'); ?></option>
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-3 control-label col-sm-offset-2">
                        <button type="submit" class="btn btn-success">
                            <i class="fa fa-check"></i> <?php echo get_phrase('save');?>
                        </button>
                    </div>
                </form>

            </div>

        </div>

    </div>
</div>
<?php }?>
<script type="text/javascript">
   $(document).ready(function(){
        $('#wardtype_id').change(function(){
            $('#warddiv').css('display','block');
            var abc = $('#wardtype_id').val();
            $.ajax({
                url: '<?php echo site_url('admin/fetch_ward')?>',
                method:'POST',
                data:{abc:abc},
                success:function (data){
                    $('#ward').html(data);
                },
                error:function(data){
                    alert('hello');
                }
            })            
        });
        $('#ward').change(function(){
            $('#bedtypediv').css('display','block');
            var abcd = $('#ward').val();
            $.ajax({
                url: '<?php echo site_url('admin/fetch_bedtype')?>',
                method:'POST',
                data:{abcd:abcd},
                success:function (data){
                    $('#bedtype').html(data);
                },
                error:function(data){
                    alert('hello');
                }
            })            
        });
   });
</script>