<?php $wardtype_info = $this->db->get('ward_type')->result_array(); ?>
<?php $ward_ino = $this->db->get('ward')->result_array(); ?>
<?php 
$single_bedtype_info = $this->db->get_where('bedtype', array('id' => $param2))->result_array();
foreach($single_bedtype_info as $row){
?>
<div class="row">
    <div class="col-md-12">

        <div class="panel panel-primary" data-collapsed="0">

            <div class="panel-heading">
                <div class="panel-title">
                    <h3 id="test"><?php echo get_phrase('Edit_BedType'); ?></h3>
                </div>
            </div>

            <div class="panel-body">

                <form role="form" class="form-horizontal form-groups validate"
                    action="<?php echo site_url('admin/bedtype/update/'.$row['id']); ?>" 
                        method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label"><?php echo get_phrase('name'); ?></label>

                        <div class="col-sm-7">
                            <input type="text" name="name" class="form-control" id="field-1" value="<?php echo $row['name'];?>" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="field-ta" class="col-sm-3 control-label"><?php echo get_phrase('description'); ?></label>

                        <div class="col-sm-7">
                            <textarea name="description" value="" class="form-control" id="field-ta"
                                rows="5"><?php echo $row['description'];?></textarea>
                        </div>
                    </div>

                    
                    <div class="form-group">
                        <label for="field-ta" class="col-sm-3 control-label"><?php echo get_phrase('Wardtype'); ?></label>

                        <div class="col-sm-7">
                            <select name="wardtype_id" class="form-control" id="wardtype_id" required
                                class="form-control">
                                <option value=""><?php echo get_phrase('Select Wardtype') ?></option>
                                <?php foreach ($wardtype_info as $ro) { ?>
                                    <option value="<?php echo $ro['id']; ?>"<?php if ($row['wardtype'] == $ro['id']) echo 'selected'; ?>><?php echo $ro['name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                     <div class="form-group">
                        <label for="field-3" class="col-sm-3 control-label"><?php echo get_phrase('Ward'); ?></label>

                        <div class="col-sm-7">
                            <select  name="ward_id" class="form-control" id="ward" required
                                class="form-control">
                                <option value=""><?php echo get_phrase('select_ward'); ?></option>
                            </select>
                        </div>
                    </div>
                    

                    <div class="col-sm-3 control-label col-sm-offset-2">
                        <button type="submit" class="btn btn-success">
                            <i class="fa fa-check"></i> <?php echo get_phrase('save');?>
                        </button>
                    </div>
                </form>

            </div>

        </div>

    </div>
</div>
<?php }?>
<script type="text/javascript">
   $(document).ready(function(){
        $('#wardtype_id').change(function(){
            var abc = $('#wardtype_id').val();
            $.ajax({
                url: '<?php echo site_url('admin/fetch_ward')?>',
                method:'POST',
                data:{abc:abc},
                success:function (data){
                    $('#ward').html(data);
                },
                error:function(data){
                    alert('hello');
                }
            })            
        })
   })
</script>